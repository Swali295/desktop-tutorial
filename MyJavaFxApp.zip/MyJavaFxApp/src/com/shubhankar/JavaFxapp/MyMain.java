package com.shubhankar.JavaFxapp;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.Optional;

public class MyMain extends Application {

    public static void main(String[] args){
        launch(args);
    }

    @Override
    public void init() throws Exception {
        System.out.println("init");
        super.init();
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        System.out.println("start");

        FXMLLoader loader = new FXMLLoader(getClass().getResource("app_layout.fxml"));
        VBox rootNode = loader.load();

        MenuBar menuBar = createMenu();
        rootNode.getChildren().addAll(menuBar);

        Scene scene = new Scene(rootNode, 300, 275);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Periodic Table");
        primaryStage.show();
    }

    private MenuBar createMenu(){

        //file menu
        Menu fileMenu = new Menu("File");
        MenuItem newMenuItem = new MenuItem("New");

        newMenuItem.setOnAction(actionEvent -> System.out.println("New Menu Item clicked"));  //lamda code

        SeparatorMenuItem separatorMenuItem = new SeparatorMenuItem();
        MenuItem quitMenuItem = new MenuItem("Quit");

        quitMenuItem.setOnAction(actionEvent -> {            //lamda code
            Platform.exit();
        });

        fileMenu.getItems().addAll(newMenuItem,separatorMenuItem,quitMenuItem);

        //Help menu
        Menu helpMenu = new Menu("Help");
        MenuItem aboutApp = new MenuItem("About");

        aboutApp.setOnAction(actionEvent -> aboutApp());

        helpMenu.getItems().addAll(aboutApp);

        //menu bar
        MenuBar menuBar = new MenuBar();
        menuBar.getMenus().addAll(fileMenu,helpMenu);
        return menuBar;

    }

    public static void aboutApp() {
        Alert alertDialogue = new Alert(Alert.AlertType.INFORMATION);
        alertDialogue.setTitle("My First Desktop App");
        alertDialogue.setHeaderText("Learning Java");
        alertDialogue.setContentText("My name is 'Shubhankar Tripathi'. ");
        alertDialogue.show();

        ButtonType yesButton = new ButtonType("Yes");
        ButtonType noButton = new ButtonType("No");
        alertDialogue.getButtonTypes().setAll(yesButton, noButton);

        Optional<ButtonType> clickedButton = alertDialogue.showAndWait();

        if (clickedButton.isPresent() && clickedButton.get() == yesButton){
            System.out.println("Yes button clicked");}
        if (clickedButton.isPresent() && clickedButton.get() == noButton){
            System.out.println("No button clicked");
        }
    }

    @Override
    public void stop() throws Exception {
        System.out.println("stop");
        super.stop();
    }
}
